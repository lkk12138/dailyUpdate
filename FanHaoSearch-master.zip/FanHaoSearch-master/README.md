###番号种子采集器
#####By 肾虚公子

官网: http://FanHao.miaowu.asia

主程序:FanHao.py

Mac/Liunx 运行程序(python FanHao.py)即可。

Windows用户请下载压缩包:[下载](https://raw.githubusercontent.com/ShenXuGongZi/FanHaoSearch/master/Win_Client.7z)

预览:

![](http://ww2.sinaimg.cn/large/9b8b0d99tw1eigjqlxzclg20ho0al0z1.gif)


#### 程序基本功能
* 全局代理抓取，自动采集代理
* 搜索并给出磁力连接
* 手机完成后自动打开网页展示信息
* 目前最大展示10个连接
